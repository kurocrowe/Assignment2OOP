#include "Game.h"
#include "Pacman.h"
#include "Ghost.h"
#include "Berry.h"

#include <iostream>
using namespace std;

Game::Game(int size) : s(size) {
    for (int i = 0; i < MAX_OBJECTS; ++i) {
        gameObjects[i] = nullptr;
    }
}

Game::~Game() {
    for (int i = 0; i < MAX_OBJECTS; ++i) {
        delete gameObjects[i];
        gameObjects[i] = nullptr;
    }
}

void Game::initGame() {
    // Create Pacman at (0,0)
    gameObjects[0] = new Pacman(0, 0);
    Pacman* pacman = dynamic_cast<Pacman*>(gameObjects[0]);
    if (pacman) pacman->setBoardSize(s, s);

    // Create Berry at fixed position (optional)
    gameObjects[1] = new Berry(); // Implement as needed

    // Create Ghost at (5,5)
    gameObjects[2] = new Ghost(5, 5);
    Ghost* ghost = dynamic_cast<Ghost*>(gameObjects[2]);
    if (ghost) ghost->setBoardSize(s, s);
}

void Game::drawWorld() {
    system("cls");
    cout << "+";
    for (int i = 0; i < s * 2; ++i) cout << "-";
    cout << "+\n";

    // Allocate board grid
    char** space = new char* [s];
    for (int i = 0; i < s; ++i) {
        space[i] = new char[s];
        for (int j = 0; j < s; ++j) {
            space[i][j] = ' ';
        }
    }

    // Place all game objects on the board
    for (int i = 0; i < MAX_OBJECTS; ++i) {
        if (gameObjects[i]) {
            int x = 0, y = 0;
            char symbol = ' ';

            if (Pacman* p = dynamic_cast<Pacman*>(gameObjects[i])) {
                x = p->getX();
                y = p->getY();
                symbol = p->getSymbol();
            }
            else if (Ghost* g = dynamic_cast<Ghost*>(gameObjects[i])) {
                x = g->getX();
                y = g->getY();
                symbol = g->getSymbol();
            }
            else if (Berry* b = dynamic_cast<Berry*>(gameObjects[i])) {
               
                x = b->getX();
                y = b->getY();
                symbol = b->getSymbol();
            }

            if (x >= 0 && x < s && y >= 0 && y < s) {
                space[y][x] = symbol;
            }
        }
    }

    // Draw board rows with side walls
    for (int i = 0; i < s; ++i) {
        for (int j = 0; j < s; ++j) {
            cout << "|" << space[i][j];
        }
        cout << "|\n";
    }

    cout << "+";
    for (int i = 0; i < s * 2; ++i) cout << "-";
    cout << "+\n";

    // Clean up
    for (int i = 0; i < s; ++i) {
        delete[] space[i];
    }
    delete[] space;
}

Game::GameState Game::doTurn() {
    Pacman* pacman = dynamic_cast<Pacman*>(gameObjects[0]);
    Ghost* ghost = dynamic_cast<Ghost*>(gameObjects[2]);
    Berry* berry = dynamic_cast<Berry*>(gameObjects[1]);

    if (pacman) {
        pacman->update(); // Move Pacman based on input
    }

    if (ghost) ghost->update();

    // Check if Pacman eats Berry
    if (pacman && berry) {
        if (pacman->getX() == berry->getX() && pacman->getY() == berry->getY()) {
            pacman->setSuper(true);
            // Remove berry from board after eating
            delete gameObjects[1];
            gameObjects[1] = nullptr;
            cout << "Pacman ate Berry and is now SUPER!\n";
        }
    }

    // Check collision Pacman-Ghost
    if (pacman && ghost) {
        if (pacman->getX() == ghost->getX() && pacman->getY() == ghost->getY()) {
            if (pacman->getSuper()) {
                // Pacman eats ghost - remove ghost
                delete gameObjects[2];
                gameObjects[2] = nullptr;
                cout << "Pacman ate the Ghost!\n";

                return GameState::Won;
                exit(0);
            }
            else {
              
                cout << "Pacman was caught by the Ghost! Game Over.\n";

                return GameState::Lost;
                exit(0);
            }
        }
    }
    return GameState::Running;
    drawWorld();
}
