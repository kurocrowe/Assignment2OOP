#pragma once
#include "Entity.h"
#include "Ghost.h"
#include "Pacman.h"   // Assuming you have these
#include "Berry.h"

class Game {
public:
    static const int MAX_OBJECTS = 8;
    Entity* gameObjects[MAX_OBJECTS];
    int s;  // board size

    Game(int size = 10);
    ~Game();
    enum class GameState {
        Running,
        Won,
        Lost
    };

    void initGame();
    void drawWorld();
   GameState doTurn();
};
