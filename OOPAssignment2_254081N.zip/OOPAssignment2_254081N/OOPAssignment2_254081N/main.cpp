#include "Game.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <conio.h>
using namespace std;

int main() {
    const int boardSize = 20;
    Game game(boardSize);

    game.initGame();


    char command;
  /*  while (true) {
        game.drawWorld();*/
     /*   cout << "Enter WASD): ";
        cin >> command;
        cout << command;
        if (command == 'q') {
            cout << "Quitting game.\n";
            break;
        }}*/

  
       
        Game::GameState state = Game::GameState::Running;

        while (state == Game::GameState::Running) {
            game.drawWorld();
            state = game.doTurn();
            std::this_thread::sleep_for(std::chrono::milliseconds(200));
        }
        cout << "Game over! Press any key to exit...";
        _getch();

        return 0;

    


 
}
